#include <iostream>
#include <iomanip>
#include <string>
#include <iostream>
#include "User.h"
using namespace std;


User :: User()
{
      username = "";
      numRatings = 0;
      for (int i = 0; i < SIZE; i++)
      {
         ratings[i] = -1;
      } 
}

User :: User(string u, int array[], int a)
{
   username = u;
   numRatings = a;
   ratings[SIZE];
   for (int j = 0; j < numRatings; j++)
   {
      ratings[j] = array[j];
   }
}

string User :: getUsername()
{
   return username;
}

void User :: setUsername(string inputT)
{
   username = inputT;
}

int User :: getRatingAt(int index)
{
   if (index >= 50)
   {
      return -1;
   }
   else 
   {
      return ratings[index];
   }
}

bool User :: setRatingAt(int index, int value)
{
   if (index >= 0 && index <= 200 && value >= 0 && value <= 5)
   {
      ratings[index] = value;
      return true;
   }
   else 
   {
      return false;
   }
}

int User :: getNumRatings()
{
   return numRatings;
}

void User :: setNumRatings(int input1)
{
   numRatings = input1;
}

int User :: getSize()
{
   return SIZE;
}

