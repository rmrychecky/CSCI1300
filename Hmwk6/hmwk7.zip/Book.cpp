#include <iostream>
#include <iomanip>
#include <string>
#include "Book.h"
using namespace std;

Book :: Book()
{
   title = "";
   author = "";
}

Book :: Book(string t, string a)
{
   title = t;
   author = a;
}

string Book :: getTitle()
{
   return title;
}

void Book :: setTitle(string inputT)
{
   title = inputT;
}

string Book :: getAuthor()
{
   return author;
}

void Book :: setAuthor(string inputA)
{
   author = inputA; 
}

